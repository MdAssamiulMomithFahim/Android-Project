package com.example.hackathonviewpagerlogin;

public interface ClickInterface {
    void onItemClick(int position);
    void onLongItemClick(int position);
}
